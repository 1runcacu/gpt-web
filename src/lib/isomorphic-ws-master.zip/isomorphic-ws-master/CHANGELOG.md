## 5.0.0 (June 27, 2022)

* Changed browser to es modules ([@guillemcordoba](https://github.com/guillemcordoba) in [#20](https://github.com/heineiuo/isomorphic-ws/pull/20))
