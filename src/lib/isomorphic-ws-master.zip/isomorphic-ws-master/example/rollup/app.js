import WebSocket from 'isomorphic-ws'


const ws = new WebSocket('ws://www.host.com/path')